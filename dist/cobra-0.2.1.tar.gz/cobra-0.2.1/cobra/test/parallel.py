"""Future test suite for parallel features
"""
from warnings import warn
warn("parallel unit tests are not yet implemented")
